import 'package:flutter/material.dart';
import 'package:web_socket_channel/io.dart';
import './Pages/login_page.dart';
import './Pages/otp_verification.dart';

void main() {
  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': ((context) => Login()),
      '/otp_verification':((context) => Otp_verifification()),
    },
  ));
}
